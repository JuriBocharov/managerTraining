BizBlog is a Multipurpose Personal Blog HTML5 Template designed to build any kinds of Personal Blogging Website.. It's an HTML5 template based on latest Bootstrap v4.x. Anyone can easily update/edit this template by following our Well Sorted Documentation.


==========================================================================
Well Sorted Documentation included in "documentation" (folder).
==========================================================================

==========================================================================
Changelog included in "documentation/changelog" (folder).
==========================================================================


SOURCE AND CREADITS:
====================

Photos:

    All 'images' used on the demo site is for demonstration purposes only and are not included in the main download file.

Fonts Used:

    Google Fonts (Montserrat and Barlow) - https://fonts.google.com
    Font Awesome - https://github.com/FortAwesome/Font-Awesome/

Frameworks / Libraries:

    jQuery - http://jquery.com
    Twitter Bootstrap - http://getbootstrap.com

Plugins Used:

    Animate CSS - https://daneden.github.io/animate.css/
    Owl Carousel - https://github.com/OwlCarousel2/OwlCarousel2
    Magnific Popup - https://dimsemenov.com/plugins/magnific-popup/